<html>
<head>
	<title>Report Data Pembeli</title>
</head>
<body>
	<?php 
		$con = mysqli_connect("localhost","root","","db_penjualan_motor");
	?>
	<form action="" method="post">
		
			<h1 align="center" style="font-family: Comic sans ms">JUAL MOTOR MURAH</h1>
			<p align="center" style="font-family: Comic sans ms">Pasar Cikereteg,Bogor,Jawa Barat,Indonesia</p>
			<p align="center" style="font-family: Comic sans ms">Telp(083811870120)</p>
		<hr>
			<h1 align="center" style="font-family: Comic sans ms">Daftar Pembeli</h1>
		<table align="center" cellspacing="0" cellpadding="10" border="1">
			<tr>
				<th>Nomor Transaksi</th>
				<th>Kode Motor</th>
				<th>Nama Motor</th>
				<th>Mesin Motor</th>
				<th>Warna Motor</th>
				<th>Harga Motor</th>
				<th>Jumlah Beli</th>
				<th>Diskon</th>
				<th>Harga Total</th>
				<th>Pembeli</th>
				<th>Membayar</th>
				<th>Kembalian</th>
				<th>Tanggal</th>
				<th>Waktu</th>
			</tr>
			<?php 
				$sql = "SELECT * FROM transaksi";
				$query = mysqli_query($con,$sql);
				while($data = mysqli_fetch_array($query)){
			 ?>
			<tr>
				<td><?= $data["id"]; ?></td>
				<td><?= $data["kode_motor"]; ?></td>
				<td><?= $data["nama_motor"]; ?></td>
				<td><?= $data["merk"]; ?></td>
				<td><?= $data["warna"]; ?></td>
				<td><?= $data["harga"]; ?></td>
				<td><?= $data["jumlahbeli"]; ?></td>
				<td><?= $data["diskon"]; ?></td>
				<td><?= $data["hargatotal"]; ?></td>
				<td><?= $data["nama"]; ?></td>
				<td><?= $data["inputuang"]; ?></td>
				<td><?= $data["kembalian"]; ?></td>
				<td><?= $data["tanggal"]; ?></td>
				<td><?= $data["waktu"]; ?></td>
			</tr>
			<?php } ?>
		</table>
		<table align="center" style="font-family: comic sans ms;font-size: 20px;">
			<br>
			<tr>
				<td>Total penghasilan : Rp.</td>
				<?php 
					$sql = "SELECT SUM(hargatotal) AS jumlah FROM transaksi";
					$jumlah = mysqli_query($con,$sql);
					$data = mysqli_fetch_array($jumlah);
				?>
				<td><?php echo $data['jumlah']; ?></td>
			</tr>
		</table>
		<hr>
	</form>
</body>
</html>
<script>
	window.onload=function(){
		window.print();
	}
</script>